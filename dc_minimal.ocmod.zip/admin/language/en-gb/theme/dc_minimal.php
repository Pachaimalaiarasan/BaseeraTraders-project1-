<?php
// Heading
$_['heading_title']            = 'Design Cart Minimal 4';

// Text
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified example theme!';
$_['text_edit']                = 'Edit Design Cart Minimal 4';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify this theme!';

//Interface
$_['tx_status']                = 'Status';
$_['tx_phone']                 = 'Phone';
$_['tx_email']                 = 'E-mail';
$_['tx_baner']                 = 'Baner';
$_['tx_header_bg']             = 'Header background color';
$_['tx_header_color']          = 'Header color';
$_['tx_title_color']           = 'Title color';
$_['tx_primary_bg']            = 'Primary background color';
$_['tx_primary_color']         = 'Primary color';
$_['tx_secondary_bg']          = 'Secondary background color';
$_['tx_secondary_color']       = 'Secondary color';
$_['tx_general']               = 'General';
$_['tx_translation']           = 'Translation';
$_['tx_phone_lab']             = 'Label for phone';
$_['tx_email_lab']             = 'Label for email';
$_['tx_cart_lab']              = 'Label for cart';
$_['tx_free_shipping']         = 'Free shipping text';
$_['tx_search_lab']            = 'Label for search';
$_['tx_modules']               = 'Modules';
$_['tx_module_mode_featured']  = 'Featured products';
$_['tx_module_mode_latest']    = 'Latest products';
$_['tx_module_mode_special']   = 'Special products';
$_['tx_module_mode_bestseller']= 'Bestseller products';
$_['tx_grid']                  = 'Grid';
$_['tx_carousel']              = 'Carousel';
$_['tx_title']                 = 'Title';
$_['tx_subtitle']              = 'Subtitle';
